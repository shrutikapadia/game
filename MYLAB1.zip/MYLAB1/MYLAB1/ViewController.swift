//
//  ViewController.swift
//  MYLAB1
//
//  Created by Shruti Kapadia on 2021-10-15./Users/shrutikapadia/Desktop/MYLAB1/MYLAB1/Base.lproj/Main.storyboard
//
import UIKit

class ViewController: UIViewController {
    
  // this is the label to print the statement " put the bull's eye ... "
    @IBOutlet weak var bull_eye: UILabel!
    
    
  // This is the text field to store output as score
    @IBOutlet weak var score_value: UITextField!
    
   
   // this is the slider outlet
    @IBOutlet weak var slider8640: UISlider!
    
    // This is outlet to display text "Score :"
    @IBOutlet weak var score: UITextField!
    
    
    // This is the label outlet right beside " bull's eye text"
    // this outlet is to display random number or target value
    
    @IBOutlet weak var label8640: UITextField!
    
   // This is text outlet to display otext " Round: " on screen
    @IBOutlet weak var Round: UITextField!
    
    // This is text outlet to display on which round player is
    @IBOutlet weak var round_value: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any aditional setup after loading the view.
    }
    
   
    // var current 0 is used for storing value from slider
    var current = 0
    @IBAction func valueslider(_ sender: Any) {
        // to take value from user through slider and store in current
        let current = Int(slider8640.value)
    }
   // result to set intial result to 0 and storing score
    var result = 0
    
    // count is used to keep track of number of round player is on
    // initial vale is set to 0
    var count = 0
    // a is used to display iitial target value
    let a = 10   

    
    @IBAction func myButton0000(_ sender: Any) {
        
        // b is used to get random number
        let b = Int.random(in: 1...100)
        // displaying random num taken from b to target value beside bull eye
        label8640.text = String(b)
        // increasing count to display the player is on next round now
        count = count + 1
        // displaying on which round the player is now
        round_value.text = String(count)
        // storing  total score of player until now
        result = result + 100 - Int(b) - current
        //displaying total score of player until now
        
        score_value.text = String(result)
        
    }
    
    
    // this function is used to resest data of game
    @IBAction func start_over(_ sender: Any) {
        
        // resesting score to 0
        score_value.text = "0"
        
        //resenting num of rounds to 0
        round_value.text = "0"
        
        // reseting helping int count to 0
        count = 0
        
        //reseting random number value with some number for next round
        label8640.text = "40"
        
        //resetiing result to 0 for fresh initialization for next battle
        result = 0
        
    }
    
}

